# -*- coding: utf-8 -*-
"""
自动部署包推送脚本
每天 17:00 自动运行，打包 workspace 配置为 zip 并推送到 GitHub
"""
import os
import subprocess
import shutil
from pathlib import Path
from datetime import datetime
import yaml
import re
import zipfile


WORKSPACE = Path(r'C:\Users\yuson\.openclaw\workspace')
TOOLBOX_REPO = Path(r'C:\Users\yuson\.openclaw\workspace\toolbox-scripts')
DEPLOY_DIR = TOOLBOX_REPO / 'myagent' / 'latest-deploy'


def package_workspace():
    """打包 workspace 核心配置为 zip 文件"""
    print('  打包 workspace 配置...')
    
    # 清理旧部署目录内容（保留目录本身）
    if DEPLOY_DIR.exists():
        for item in DEPLOY_DIR.iterdir():
            if item.is_file():
                item.unlink()
            elif item.is_dir():
                shutil.rmtree(item)
    DEPLOY_DIR.mkdir(parents=True, exist_ok=True)
    
    # 要打包的文件/目录
    files_to_pack = [
        'AGENTS.md',
        'SOUL.md',
        'TOOLS.md',
        'MEMORY.md',
        'USER.md',
        'IDENTITY.md',
        'HEARTBEAT.md',
    ]
    
    dirs_to_pack = [
        'scripts',
        'memory',
    ]
    
    # 创建 zip 包
    zip_name = f'workspace_deploy_{datetime.now().strftime("%Y%m%d")}.zip'
    zip_path = DEPLOY_DIR / zip_name
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        # 打包单文件
        for fname in files_to_pack:
            fpath = WORKSPACE / fname
            if fpath.exists():
                zf.write(fpath, fname)
                print(f'    + {fname}')
        
        # 打包目录
        for dirname in dirs_to_pack:
            dirpath = WORKSPACE / dirname
            if dirpath.exists():
                for root, dirs, files in os.walk(dirpath):
                    for file in files:
                        file_path = Path(root) / file
                        arcname = str(file_path.relative_to(WORKSPACE))
                        zf.write(file_path, arcname)
                print(f'    + {dirname}/')
    
    print(f'  zip 包: {zip_name} ({zip_path.stat().st_size / 1024:.1f} KB)')
    
    # 写部署说明
    deploy_readme = DEPLOY_DIR / 'DEPLOY_README.md'
    deploy_readme.write_text(f'''# 部署包

**打包时间**: {datetime.now().strftime("%Y-%m-%d %H:%M")}

## 包含内容

- workspace 核心 md 文件（AGENTS.md、SOUL.md、TOOLS.md、MEMORY.md 等）
- scripts/ 目录（auto_package_push.py、safe_delete.py）
- memory/ 目录（日志文件）

## 新电脑部署步骤

1. 解压 `{zip_name}` 到 OpenClaw workspace 目录（`~/.openclaw/workspace/`）
2. 替换 OpenClaw `config/openclaw.json` 中的 apiKey 和 gateway token
3. 替换 HuggingFace 工具的 config.yaml 中的智谱 Key（如需要）
4. 运行 `gh auth login` 配置 GitHub 认证
5. 配置 Git 代理（如需要）

## 脱敏说明

所有敏感信息已替换为占位符：
- 智谱 API Key → `${{ZHIPU_API_KEY}}`
- LiteLLM API Key → `${{API_KEY}}`
- GitHub Token → `${{GITHUB_TOKEN}}`
- Gateway Token → `${{GATEWAY_TOKEN}}`
''', encoding='utf-8')
    
    return zip_path


def sanitize_toolbox_configs():
    """脱敏 toolbox 仓库下的 config.yaml"""
    configs = list(TOOLBOX_REPO.glob('huggingface-dataset-extractor/*/config.yaml'))
    originals = {}
    
    for config_file in configs:
        content = config_file.read_text(encoding='utf-8')
        originals[config_file] = content
        
        # 替换敏感信息
        sanitized = re.sub(
            r'(api_key:\s*)[^\s\n]+',
            r'\1${ZHIPU_API_KEY}',
            content
        )
        config_file.write_text(sanitized, encoding='utf-8')
    
    return originals


def restore_toolbox_configs(originals):
    """推送后还原本地 config.yaml 的真实 key"""
    for config_file, content in originals.items():
        config_file.write_text(content, encoding='utf-8')
        print(f'  还原: {config_file.relative_to(TOOLBOX_REPO)}')


def git_push():
    """提交并推送到 GitHub"""
    os.chdir(TOOLBOX_REPO)
    
    # 0. 更新仓库 README 时间戳
    readme_path = TOOLBOX_REPO / 'README.md'
    if readme_path.exists():
        content = readme_path.read_text(encoding='utf-8')
        content = re.sub(
            r'_最后更新: .*_',
            f'_最后更新: {datetime.now().strftime("%Y-%m-%d")}_',
            content
        )
        readme_path.write_text(content, encoding='utf-8')
    
    # 1. 脱敏 toolbox 下的 config.yaml
    print('  脱敏 config 文件...')
    originals = sanitize_toolbox_configs()
    
    # 2. add 部署包 + toolbox 改动 + 根目录文件
    subprocess.run(['git', 'add', 'myagent/latest-deploy/'],
                   capture_output=True, text=True)
    subprocess.run(['git', 'add', 'huggingface-dataset-extractor/'],
                   capture_output=True, text=True)
    subprocess.run(['git', 'add', 'salary-calculator/'],
                   capture_output=True, text=True)
    subprocess.run(['git', 'add', 'README.md'],
                   capture_output=True, text=True)
    subprocess.run(['git', 'add', '.gitignore'],
                   capture_output=True, text=True)
    
    # 检查是否有变更
    result = subprocess.run(['git', 'status', '--porcelain'],
                          capture_output=True, text=True)
    
    if not result.stdout.strip():
        print('  没有变更，跳过推送')
        restore_toolbox_configs(originals)
        return True
    
    # 提交
    msg = f'auto: deploy package + toolbox updates ({datetime.now().strftime("%Y-%m-%d")})'
    subprocess.run(['git', 'commit', '-m', msg], capture_output=True, text=True)
    
    # 推送
    result = subprocess.run(['git', 'push'], capture_output=True, text=True, timeout=60)
    if result.returncode == 0:
        print('  ✓ 已推送到 GitHub')
    else:
        print(f'  ✗ 推送失败: {result.stderr}')
    
    # 3. 无论推送成功失败，都还原本地真实 key
    print('  还原本地 config...')
    restore_toolbox_configs(originals)
    
    return result.returncode == 0


if __name__ == '__main__':
    print(f'[{datetime.now().strftime("%Y-%m-%d %H:%M")}] 开始打包部署文件...')
    
    try:
        zip_path = package_workspace()
        print(f'\n✓ 打包完成: {zip_path.name}')
        
        print('\n推送到 GitHub...')
        success = git_push()
        
        if success:
            print('\n✓ 全部完成')
        else:
            print('\n✗ 推送失败，但 zip 包已生成')
    except Exception as e:
        print(f'\n✗ 错误: {e}')
        import traceback
        traceback.print_exc()
